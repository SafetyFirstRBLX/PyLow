import tkinter as tk
import tkinter.font as tkfont
import os

def stage1_boot():
    root = tk.Tk()
    root.title("PyLow Boot Stage 1")
    root.geometry("800x600")
    root.configure(bg="black")

    available_fonts = tkfont.families()
    if "JetBrains Mono" in available_fonts:
        font_family = "JetBrains Mono"
    else:
        print("JET BRAINS MONO NOT FOUND!")
        font_family = ("Inconsolata", "Courier New", "Courier")

    font_size = 14

    text = tk.Text(root, bg="black", fg="white", insertbackground="white",
                   font=(font_family, font_size), bd=0, highlightthickness=0)
    text.pack(expand=True, fill="both")
    text.configure(state='disabled')

    def print_line(line, color="white"):
        text.configure(state='normal')
        text.insert(tk.END, line + "\n", ("color",))
        text.tag_configure("color", foreground=color)
        text.see(tk.END)
        text.configure(state='disabled')

    disk_path = os.path.join(os.path.dirname(__file__), "..", "disk", "emudisk.img")
    disk_exists = os.path.exists(disk_path)

    lines = [
        ("Attempting to boot into system...", "white"),
        ("Checking for emulated disk....", "white"),
    ]

    if disk_exists:
        lines.append(("Disk detected!", "green"))
        lines.append(("Loading binary. ", "white"))
    else:
        lines.append(("Disk not detected", "red"))

    def print_lines(index=0):
        if index < len(lines):
            line, color = lines[index]
            print_line(line, color)
            root.after(3000, lambda: print_lines(index + 1))

    root.bind("<Escape>", lambda e: root.destroy())
    print_lines()
    root.mainloop()

if __name__ == "__main__":
    stage1_boot()
