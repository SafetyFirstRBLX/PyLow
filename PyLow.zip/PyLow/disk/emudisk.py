import os

DISK_PATH = os.path.join(os.path.dirname(__file__), "emudisk.img")
DISK_SIZE = 1024 * 1024  # 1 MB disk size
BLOCK_SIZE = 512         # Block size in bytes (like a sector)

class EmuDisk:
    def __init__(self):
        if not os.path.exists(DISK_PATH):
            self.format_disk()
        self.disk_file = open(DISK_PATH, "r+b")  # Open for reading and writing in binary mode

    def format_disk(self):
        with open(DISK_PATH, "wb") as f:
            f.write(b"\x00" * DISK_SIZE)

    def read_block(self, block_num):
        if block_num < 0 or block_num * BLOCK_SIZE >= DISK_SIZE:
            raise ValueError("Block number out of range")
        self.disk_file.seek(block_num * BLOCK_SIZE)
        return self.disk_file.read(BLOCK_SIZE)

    def write_block(self, block_num, data):
        if block_num < 0 or block_num * BLOCK_SIZE >= DISK_SIZE:
            raise ValueError("Block number out of range")
        if len(data) != BLOCK_SIZE:
            raise ValueError(f"Data must be exactly {BLOCK_SIZE} bytes")
        self.disk_file.seek(block_num * BLOCK_SIZE)
        self.disk_file.write(data)
        self.disk_file.flush()

    def close(self):
        self.disk_file.close()


# Example usage:
if __name__ == "__main__":
    disk = EmuDisk()

    # Write a block filled with 'A's
    data = b'A' * BLOCK_SIZE
    disk.write_block(0, data)

    # Read it back
    read_data = disk.read_block(0)
    print(read_data)

    disk.close()
